import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_map/plugin_api.dart';
import 'package:flutter_map_location_marker/flutter_map_location_marker.dart';
import 'package:flutter_map_marker_cluster/flutter_map_marker_cluster.dart';
import 'package:latlong2/latlong.dart';
import 'package:syncfusion_flutter_maps/maps.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:open_route_service/open_route_service.dart';
import 'package:geolocator/geolocator.dart';



class MapPage extends StatefulWidget{

  MapPage({super.key});

  @override
  State createState() => _InitExampleState();

}

class _InitExampleState extends State{
  List<Marker> markers = [];
  MapZoomPanBehavior? _zoomPanBehavior;

  @override
  void initState() {
    requestLocationPermission();
    _zoomPanBehavior = MapZoomPanBehavior();
    Timer.periodic(Duration(seconds: 10), (timer) {

      setState((){
        routeCalc();

        // perform your actions here
      });
    });
    super.initState();

  }


  @override
  Widget build(BuildContext context) {
    return FutureBuilder(future:routeCalc(),builder: (BuildContext context, AsyncSnapshot snapshot) {

      if (snapshot.data != null) {

        return FlutterMap(

          options: MapOptions(
              center: LatLng(50.565385, 9.688258),
              zoom: 15
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            ),
            currentLocationLayerFunc(),
            MarkerLayer(

              rotate: true,
              markers: [
                Marker(point: LatLng(goals[0].latitude, goals[0].longitude),width:80,height:80,builder: (context) => GestureDetector(onTap: () {
                  print("jooo");
                  dialogBuilder(context);
                },
                    child: IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){dialogBuilder(context);},
                  ),



                ),
                ),
                /*Marker(point: LatLng(goals[1].latitude, goals[1].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      dialogBuilder(context);
                    },
                  ),

                  ),
                ),
                Marker(point: LatLng(goals[2].latitude, goals[2].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[3].latitude, goals[3].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[4].latitude, goals[4].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[5].latitude, goals[5].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[6].latitude, goals[6].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[7].latitude, goals[7].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[8].latitude, goals[8].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[9].latitude, goals[9].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[10].latitude, goals[10].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[11].latitude, goals[11].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[12].latitude, goals[12].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[13].latitude, goals[13].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[14].latitude, goals[14].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[15].latitude, goals[15].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),
                Marker(point: LatLng(goals[16].latitude, goals[16].longitude),builder: (context) => new Container(
                  child:IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: (){
                      print('Marker tapped');
                    },
                  ),

                ),
                ),

                 */
            ],
      ),
            PolylineLayer(
              polylineCulling: false,
              polylines: [
                Polyline(
                    points: snapshot.data,
                    color: Colors.green,
                    strokeWidth: 3

                ),
              ],
            ),
          ],
        );
      }
      else {
        return const Text("loading");
      }
    });
  }

}


CurrentLocationLayer currentLocationLayerFunc() {

  return CurrentLocationLayer(


    //centerOnLocationUpdate: CenterOnLocationUpdate.always,
    turnOnHeadingUpdate: TurnOnHeadingUpdate.never,
    style: const LocationMarkerStyle(
      showAccuracyCircle: true,
      marker: DefaultLocationMarker(
        child: Icon(
          Icons.navigation,
          size: 10,
          color: Colors.white,
        ),
      ),
      markerSize: const Size(15, 15),
      markerDirection: MarkerDirection.heading,

    ),
  );
}

void  requestLocationPermission() async {

  PermissionStatus permission = await Permission.location.request();
  if (permission == PermissionStatus.granted) {
    // The permission was granted
  } else {
    // The permission was denied
  }

}
int index = 0;
Future<List<LatLng>> routeCalc() async {
  Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);


  //Liste zum Anlegen neuer Ziele


  // Initialize the openrouteservice with your API key.
  final OpenRouteService client = OpenRouteService(apiKey: '5b3ce3597851110001cf6248f6262135c4d844bc836cdd2554165582');
  double distanceInMeters = Geolocator.distanceBetween(goals[index].latitude, goals[index].longitude, position.latitude, position.longitude);
  // Example coordinates to test between
  print(distanceInMeters);
  if(distanceInMeters<40){
    index = index + 1;
    print(index);
  }
  double endLat = goals[index].latitude;
  double endLng = goals[index].longitude;

  // Form Route between coordinates
  final List<ORSCoordinate> routeCoordinates = await client.directionsRouteCoordsGet(
    startCoordinate: ORSCoordinate(latitude: position.latitude, longitude: position.longitude),
    endCoordinate: ORSCoordinate(latitude: endLat, longitude: endLng),
  );


  // Print the route coordinates
  routeCoordinates.forEach(print);

  // Map route coordinates to a list of LatLng (requires google_maps_flutter package)
  // to be used in the Map route Polyline.
  final List<LatLng> routePoints = routeCoordinates
      .map((coordinate) => LatLng(coordinate.latitude, coordinate.longitude))
      .toList();
  return routePoints;
  // Create Polyline (requires Material UI for Color)
  /*final Polyline routePolyline = Polyline(
    polylineId: PolylineId('route'),
    visible: true,
    points: routePoints,
    color: Colors.red,
    width: 4,
  );
  */

  // Use Polyline to draw route on map or do anything else with the data :)
}



//Preset für die Ziele
// Der Konstruktor braucht einen Namen, Eine ID, die Parameter des Ziels, können per rechtsklick in Google kopiert werden
// ein Bild(wird mit der URL aufgerufen und der Infotext zum Ziel
class Goal{
  int goalId = 0;
  String name = "";

  double latitude = 0;
  double longitude = 0;
  String picture = "";
  String infoText ="";

  Goal(int goalId, String name, double latitude, double longitude, String picture, String infoText){
    this.goalId = goalId;
    this.name = name;
    this.latitude = latitude;
    this.longitude = longitude;
    this.picture = picture;
    this.infoText = infoText;
  }

  //Getter Lat
   double get latitudeValue {
    return latitude;
  }
  //Getter Long
  double get longitudeValue {
    return longitude;
  }
}






List<Goal> goals = [
  Goal(1, "10 SSC", 50.565511, 9.686294, "assets/Campusplan/10SSC.jpeg", 'Student Service Center (SSC) ,Infothek, Poststelle, Tagungsraum, Studienbüro, International Office, Zentrale Studienberatung, Validierungsautomaten, Wasserspender'),

  Goal(2, "11 Mensa", 50.56563492334587, 9.68688584796792, "assets/Campusplan/11Mensa.jpeg", 'Mensa FB Oecotrophologie, Geldbörsenaufwertungsgeräte, Geldautomat (Sparkasse)'),

  Goal(3, "12 Bibliothek", 50.56520531601582, 9.687545278390399, "assets/Campusplan/12Bib.jpeg", 'Hochschul- und Landesbibliothek'),

  Goal(4, "20", 50.56502540993165, 9.688010554126693, "assets/Campusplan/20.jpeg", 'Seminarräume Zentralverwaltung'),

  Goal(5, "21", 50.56548156496265, 9.688460372201549, "assets/Campusplan/21.jpeg", 'FB Sozialwesen'),

  Goal(6, "22", 50.56604103490536, 9.68897537570378, "assets/Campusplan/22.jpeg", 'FB Sozial- und Kulturwissenschaften, Kinderkrippe akadeMINIS e.V.'),

  Goal(7, "23", 50.566646622315766, 9.688889384675395, "assets/Campusplan/23.jpeg", 'FB Sozial- und Kulturwissenschaften, FB Wirtschaft, Studentenwerk Gießen ,Zentralverwaltung'),

  Goal(8, "24", 50.56717979202649, 9.688532107212355, "assets/Campusplan/24.jpeg", 'FB Gesundheitswissenschaften, FB Sozial- und Kulturwissenschaften, FB Sozialwesen'),

  Goal(9, "25", 50.5646104670265, 9.688471128069633, "assets/Campusplan/25.jpeg", 'FB Gesundheitswissenschaften'),

  Goal(10, "26", 50.56747321698415, 9.688791179635553, "assets/Campusplan/26.jpeg", 'FB Gesundheitswissenschaften, FB Sozialwesen, Zentralverwaltung'),

  Goal(11, "30", 50.56430942305091, 9.687402432043951, "assets/Campusplan/30.jpeg", 'FB Elektrotechnik und Informationstechnik, FB Wirtschaft'),

  Goal(12, "31", 50.56375709365506, 9.686859014966355, "assets/Campusplan/31.jpeg", 'FB Lebensmitteltechnologie, FB Gesundheitswissenschaften'),

  Goal(13, "32", 50.56375981480126, 9.68637085224987, "assets/Campusplan/32.jpeg", 'Präsidium, FB Elektrotechnik und Informationstechnik, FB Lebensmitteltechnologie'),

  Goal(14, "33", 50.564608436944475, 9.686565605197107, "assets/Campusplan/33.jpeg", 'FB Elektrotechnik und Informationstechnik, FB Lebensmitteltechnologie'),

  Goal(15, "34", 50.56317690009005, 9.68692455964886, "assets/Campusplan/34.jpeg", 'Büroräume, Seminarräume'),

  Goal(16, "35", 50.564049308170425, 9.686003762152861, "assets/Campusplan/35.jpeg", 'RIGL-Fulda'),

  Goal(17, "36", 50.56370273663435, 9.687646266914873, "", 'Büroräume'),

  Goal(18, "40", 50.56465033845177, 9.68604445024874, "assets/Campusplan/40.jpeg", 'FB Oecotrophologie'),

  Goal(19, "41", 50.564251349148314, 9.685701609889565, "assets/Campusplan/41.jpeg", 'Zentralverwaltung'),

  Goal(20, "42,", 50.563731447654924, 9.684952824985297, "assets/Campusplan/42.jpeg", 'Zentralverwaltung'),

  Goal(21, "43", 50.56416606606, 9.685057511421006, "assets/Campusplan/43.jpeg", 'FB Angewandte Informatik, FB Wirtschaft, Zentralverwaltung'),

  Goal(22, "44 SLZ", 50.56445343587642, 9.685222021423177, "assets/Campusplan/44SLZ.jpeg", 'Selbstlernzentrum (SLZ), Familienzentrum, Ruheraum, Wasserspender, Kaffeeautomat'),

  Goal(23, "45", 50.56482392514887, 9.685035078267127, "assets/Campusplan/45.jpeg", 'Hochschulsport, FB Sozialwesen Ruheraum'),

  Goal(24, "46", 50.56509941616678, 9.685487479682147, "assets/Campusplan/46.jpeg", 'FB Angewandte Informatik, FB Oecotrophologie, Rechenzentrum, Café Chaos, Aufwerter (Guthaben für Drucken/Kopieren)'),

  Goal(25, "50", 50.56546990239403, 9.684649978478769, "assets/Campusplan/50.jpeg", 'FB Lebensmitteltechnologie, AStA'),

  Goal(26, "51", 50.565135039234086, 9.684582679351829, "assets/Campusplan/51.jpeg", 'FB Angewandte Informatik, Copyshop, Aufwerter (Guthaben für Drucken/Kopieren)'),

  Goal(27, "52", 50.56486825620677, 9.684549811672213, "assets/Campusplan/52.jpeg", 'Halle 8'),

  Goal(28, "53", 50.56516818288133, 9.683932650128625, "assets/Campusplan/53.jpeg", 'FB Gesundheitswissenschaften, Hochschulsport'),

  Goal(29, "54", 50.56546493383784, 9.684226745213559, "assets/Campusplan/54.jpeg", 'FB Gesundheitswissenschaften, Hochschulsport'),

  Goal(30, "FOOD TRUCK", 50.56470159774071, 9.685887304579172, "assets/Campusplan/FOODTRUCK.jpeg", 'Food Truck „5 DAYS A WEEK”'),

  Goal(31, "Sport", 50.56594275400304, 9.688147164703876, "assets/Campusplan/Sport.jpeg", 'Basketball Spielfeld, Fußball Spielfeld'),

  Goal(32, "Hängematten", 50.56449341394203, 9.686914229910528, "assets/Campusplan/Hängematten.jpeg", ''),

  Goal(33, "Café Chaos", 50.5651429326376, 9.685078394233303, "assets/Campusplan/CaféChaos.jpeg", ''),

  Goal(34, "Copy Shop", 50.565234838803946, 9.684693733714592, "assets/Campusplan/CopyShop.jpeg", ''),

//Bushaltestellen
  Goal(35, "H", 50.56323239256676, 9.6866957366047, "", ''),

  Goal(36, "H", 50.56423391227678, 9.687617600279122, "", ''),

  Goal(37, "H", 50.56663143656019, 9.68999419845286, "", ''),

  Goal(38, "H", 50.56676881687665, 9.68988214647728, "", ''),

//Parkplätze
  Goal(39, "P1", 50.565213960786956, 9.68290900823376, "", ''),

  Goal(40, "P2", 50.565752342287155, 9.683322063906719, "", ''),

  Goal(41, "P3", 50.56996033791092, 9.687350745342787, "", ''),
];

Future<void> dialogBuilder(BuildContext context) {
  print("hier");
  return showDialog<void>(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text('Basic dialog title'),
        content: const Text('A dialog is a type of modal window that\n'
            'appears in front of app content to\n'
            'provide critical information, or prompt\n'
            'for a decision to be made.'),
        actions: <Widget>[
          TextButton(
            style: TextButton.styleFrom(
              textStyle: Theme.of(context).textTheme.labelLarge,
            ),
            child: const Text('Disable'),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          TextButton(
            style: TextButton.styleFrom(
              textStyle: Theme.of(context).textTheme.labelLarge,
            ),
            child: const Text('Enable'),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}